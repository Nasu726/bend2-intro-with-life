# Bend 2を使いこなす — 学習用セット（執筆途中）

PDFを読み、examples/ 内のコードを実行してください。
初稿は執筆途中です。GUI、操作列の保存・復元、4×4・地雷2個限定の
「運ゲー無し」盤面生成を含みます。
10×10 GUIのS/Lによる保存・復元・成否通知はLinux X11仮想画面で有限検証済みです。
物理GPU・他OS、原子的保存、スクリーンリーダー通知、対話CLI、任意サイズの盤面生成は未完成です。

公式ガイド: https://github.com/bendlang/bend/blob/main/guide/GUIDE.md

例: bend examples/01_set.bend
バイトの分割読み込み（45を先に実行して4バイトのファイルを作る）:
bend examples/45_binary_file.bend
bend examples/54_binary_chunks.bend
期待結果: 2, 2, 0, 0（4行）
時計の生の値と0/20/100ms待機を比較:
bend examples/55_clock_intervals.bend
期待結果: 6行の自然数。時刻そのものは毎回変わります。
順次atomic.addで二つのセルの更新前と更新後を確かめる:
bend examples/56_atomic_two_cells.bend
期待結果: 5、5、8、12（4行）。GPUや並列競合を検証した例ではありません。
4×4盤面のCLIリプレイ実習（対話入力ではなく引数を一括指定）:
bend examples/minesweeper/cli_replay.bend c0 f1 c1
操作 c番号=左クリック、f番号=旗、r=リセット。
初期地雷マスク33は固定で、表示する盤面には隠れた地雷位置を出しません。

別の起動でも同じCLI盤面へ戻るため、現在のディレクトリへ操作履歴を保存:
bend examples/minesweeper/cli_save.bend save c0 f1
bend examples/minesweeper/cli_save.bend load
保存形式はBEND2-SAVE-1|c0|f1|ENDで、破損した形式は拒否します。
GUIの状態全体を保存する機能ではありません。

公開済みの数字だけで確実にクリアできる候補を生成（4×4・地雷2個・左上開始限定）:
bend examples/minesweeper/noguess_generator.bend
期待結果: mines=40960;moves=0,12,14
生成器は真の地雷配置を持ちますが、推論器へは公開数字しか渡しません。

10×10の二領域をBendでクリック0→99と進めて勝利（GUIではない）:
bend examples/minesweeper/nxn_playthrough.bend
期待結果: 110（100番台はWonの検査用符号）

三つの公開数字と六つの未知マスを使う限定Bend推論:
bend examples/minesweeper/nxn_public_three_bridge.bend
期待結果: 341（候補数2、安全ビット14、地雷ビット1）
六マスが盤面の未公開マス全体でないとき、地雷総数を局所推論へ
誤適用してはいけません。一般N×Nの自動生成器は未完成です。

公開数字0/2/6の一数字推論を三回手動でつなぐBend実習:
bend examples/minesweeper/nxn_public_three_step.bend
期待結果: 5（Safeタグ1 + Minesタグ2 + Minesタグ2）
確定安全1/3/4、地雷5/7。これは既知集合を手で渡す例です。

公開数字の個数を固定しない単独規則の固定点反復:
bend examples/minesweeper/nxn_public_many_fixpoint.bend
期待結果: 6（公開済み1/2/4/5と新たな安全7/8の計6マス）
三数字だけの固定点反復（比較用）:
bend examples/minesweeper/nxn_public_three_fixpoint.bend
期待結果: 206（確定地雷2マス、確定安全6マス）

単独規則で止まる二数字から、部分集合規則で安全を確定:
bend examples/minesweeper/nxn_public_pair_gap.bend
期待結果: 203（既知安全2マス、差集合で追加安全3マス）
これは未知近傍を手で渡す有限教材で、一般N×Nの完全連立推論ではありません。

10×10保存・読込の成否を画面右端のタイルで表示するGUI（任意で選択）:
bend examples/minesweeper/nxn_gui_status_app.bend -o minesweeper10status
./minesweeper10status
S成功は緑1個、L成功は青2個、S失敗は赤3個、L失敗は橙4個の四角で表示します。
保存データはminesweeper_nxn_save.txt。旧版nxn_gui_app_store.bendも残します。

4×4マインスイーパーのGUIをネイティブビルドして起動:
bend examples/minesweeper/gui.bend -o minesweeper
./minesweeper
左クリックで公開、右クリックで旗、Rでリセット、Escで終了。
Linuxではlibx11-dev等の環境依存ライブラリが必要です。
GUIのBend型検査・ネイティブコンパイル・純粋な座標処理はCI検査済みですが、
実際のデスクトップ環境でのウィンドウ操作・見た目は別途確認してください。

10×10の初手生成GUI（headless検査とLinux X11仮想画面での操作を検証済み）:
bend examples/minesweeper/nxn_gui_render.bend
期待結果: 8689825（初手前の左上マスの内部色。画面の描画ではありません）
bend examples/minesweeper/nxn_gui_app.bend --check-only
デスクトップ環境がある場合だけ、実機起動を試してください:
bend examples/minesweeper/nxn_gui_app.bend -o minesweeper10
./minesweeper10
10×10の有効範囲は左上320×320画素、ウィンドウ全体は512×512画素です。
37件のheadless描画・旗テストは、一般のOS環境での動作を保証しません。

保存対応GUIを起動し、公開操作履歴をSで保存、Rでリセット、Lで復元:
bend examples/minesweeper/nxn_gui_app_store.bend --check-only
bend examples/minesweeper/nxn_gui_app_store.bend -o minesweeper10save
./minesweeper10save
保存先: 起動したディレクトリのminesweeper_nxn_save.txt
形式: BEND2-GUI-1|seed|操作コード...|END
操作コード=2*セル番号+ボタン（左0・右1）。0..199、最大512操作。
初回L・破損ファイル・書込不能時にもGUIを継続しますが、
失敗の画面通知と原子的な上書き保存は未実装です。
X11仮想画面での操作と再起動後復元は検証済みです。
物理GPU・他OSの実機保証ではありません。

07_gui_hello.bend はウィンドウ表示が可能な環境が必要です。
証明例: bend examples/04_flag_laws.bend --verdict
帰納法: bend examples/33_nat_induction.bend --verdict
（Leanのインストールが別途必要です）

進捗・参考実装はリポジトリを参照してください:
https://github.com/Nasu726/bend2-intro-with-life/tree/feat/intermediate-minesweeper-textbook/intermediate

このZIPは学習用です。リポジトリ全体の複製ではありません。
ライセンスは同梱のLICENSEを参照してください。
