# Bend 2を使いこなす — 学習用セット（執筆途中）

PDFを読み、examples/ 内のコードを実行してください。
初稿は執筆途中です。GUI、操作列の保存・復元、4×4・地雷2個限定の
「運ゲー無し」盤面生成を含みます。
ただしGUI実機確認、GUI保存、対話CLI、任意サイズの盤面生成は未完成です。

公式ガイド: https://github.com/bendlang/bend/blob/main/guide/GUIDE.md

例: bend examples/01_set.bend
4×4盤面のCLIリプレイ実習（対話入力ではなく引数を一括指定）:
bend examples/minesweeper/cli_replay.bend c0 f1 c1
操作 c番号=左クリック、f番号=旗、r=リセット。
初期地雷マスク33は固定で、表示する盤面には隠れた地雷位置を出しません。

別の起動でも同じCLI盤面へ戻るため、現在のディレクトリへ操作履歴を保存:
bend examples/minesweeper/cli_save.bend save c0 f1
bend examples/minesweeper/cli_save.bend load
保存形式はBEND2-SAVE-1|c0|f1|ENDで、破損した形式は拒否します。
GUIの状態全体を保存する機能ではありません。

公開済みの数字だけで確実にクリアできる候補を生成（4×4・地雷2個・左上開始限定）:
bend examples/minesweeper/noguess_generator.bend
期待結果: mines=40960;moves=0,12,14

N×Nの公開数字0から安全候補を探す（2〜100、左上0番の実習）:
bend examples/minesweeper/nxn_neighbors.bend
bend examples/minesweeper/nxn_zero_inference.bend
どちらも期待結果は3。近傍列挙と確定安全候補の個数を区別します。
これは一般の連立ソルバーや運ゲー無し生成器ではありません。
生成器は真の地雷配置を持ちますが、推論器へは公開数字しか渡しません。

4×4マインスイーパーのGUIをネイティブビルドして起動:
bend examples/minesweeper/gui.bend -o minesweeper
./minesweeper
左クリックで公開、右クリックで旗、Rでリセット、Escで終了。
Linuxではlibx11-dev等の環境依存ライブラリが必要です。
GUIのBend型検査・ネイティブコンパイル・純粋な座標処理はCI検査済みですが、
実際のデスクトップ環境でのウィンドウ操作・見た目は別途確認してください。

07_gui_hello.bend はウィンドウ表示が可能な環境が必要です。
証明例: bend examples/04_flag_laws.bend --verdict
帰納法: bend examples/33_nat_induction.bend --verdict
（Leanのインストールが別途必要です）

進捗・参考実装はリポジトリを参照してください:
https://github.com/Nasu726/bend2-intro-with-life/tree/feat/intermediate-minesweeper-textbook/intermediate

このZIPは学習用です。リポジトリ全体の複製ではありません。
ライセンスは同梱のLICENSEを参照してください。
