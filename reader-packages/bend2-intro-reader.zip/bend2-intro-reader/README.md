# Bend 2 入門 — 学習用セット

このフォルダのPDFを読み、examples/ のサンプルを動かしてください。
Bend 2 の導入方法は公式ガイドを参照してください:
https://github.com/bendlang/bend/blob/main/guide/GUIDE.md

まず bend examples/01_hello.bend を実行します。
12_affine_probe_INVALID.bend は失敗を観察する専用例です。

ライフゲームの完成版や演習の参考実装はこのZIPには入りません。
必要なときだけリポジトリの src/ を参照してください:
https://github.com/Nasu726/bend2-intro-with-life/tree/main/src

原稿・CI・編集用資料もZIPには含めていません。
ライセンスは同梱のLICENSEを参照してください。
